using System;

class PlayerData
{
  public string name;
  public string position;

  public PlayerData(){}

  public PlayerData(string name, string position)
  {
    this.name = name;
    this.position = position;
  }
}