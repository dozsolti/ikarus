# SocketIO-Unity
Basic Unity multiplayer using Socket-IO and Node

The node server repositiory - https://github.com/Rahul-Bhargav/SocketIO-game-node