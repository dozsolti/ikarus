﻿namespace SocketIOClient.Transport
{
    public enum TransportProtocol
    {
        Polling,
        WebSocket
    }
}
